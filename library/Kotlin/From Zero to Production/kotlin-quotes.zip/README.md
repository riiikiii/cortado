# Kotlin quotes companion

Run commands from the directory containing pom.xml. The Kotlin/JVM field guides provide the explanations. Target JDK 21, Maven 3.9.x, Kotlin 2.2.21, Spring Boot 3.5.16 and PostgreSQL 17.

    mvn clean verify
    mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=quotes.Walkthrough

Other standalone entry points are quotes.Types, quotes.PolicyDemo, quotes.Concurrent and quotes.SharedState.

    docker compose up --build -d
    curl -fsS http://127.0.0.1:8080/actuator/health/readiness
    python3 ops/smoke.py
    docker compose stop

Wait for readiness before running the HTTP test. It appends one row per run. Compose binds the API and PostgreSQL to loopback and stores data in a named volume. For deployment use the registry and cluster instructions in the rollout guide. Replace IMAGE_REF in ops/app.yaml and supply the quotes-db secret. The verification workflow is intended for an application repository containing this project at its root.
