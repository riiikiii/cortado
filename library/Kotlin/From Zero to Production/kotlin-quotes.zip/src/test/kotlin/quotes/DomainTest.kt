package quotes

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class DomainTest {
    @Test fun parsesAndComparesByValue() {
        assertEquals(Quote("GILT", 10125), parseLine("GILT, 10125"))
    }
    @Test fun rejectsBadFeedData() {
        for (line in listOf("GILT,", "x,12", "GILT,0", "GILT,1,2", "GILT,9223372036854775808")) {
            assertNull(parseLine(line), line)
        }
    }
    @Test fun copyChecksInvariants() {
        assertThrows(IllegalArgumentException::class.java) { Quote("GILT", 1).copy(ticks = 0) }
    }
}
