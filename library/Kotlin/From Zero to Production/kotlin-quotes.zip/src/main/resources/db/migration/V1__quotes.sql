CREATE TABLE quotes (
    id uuid PRIMARY KEY,
    symbol text NOT NULL CHECK (symbol ~ '^[A-Z]{1,8}$'),
    ticks bigint NOT NULL CHECK (ticks BETWEEN 1 AND 1000000000)
);
