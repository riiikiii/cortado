package quotes

object Walkthrough {
    @JvmStatic
    fun main(args: Array<String>) {
        val lines = args.toList().ifEmpty { listOf("GILT,10125", "GILT,10130", "BAD,?") }
        val quotes = lines.mapNotNull(::parseLine)
        println("accepted=${quotes.size} rejected=${lines.size - quotes.size}")
        val best = quotes.groupBy { it.symbol }
            .mapValues { (_, group) -> group.maxOf { it.ticks } }
        println(best)
    }
}
