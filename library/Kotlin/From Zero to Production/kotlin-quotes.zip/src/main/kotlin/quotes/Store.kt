package quotes

import java.util.UUID
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Component

interface QuoteStore {
    fun record(id: UUID, quote: Quote): Booking
    fun find(id: UUID): Quote?
}

@Component
class SqlStore(private val db: JdbcTemplate) : QuoteStore {
    override fun record(id: UUID, quote: Quote): Booking {
        val count = db.update(
            "INSERT INTO quotes(id,symbol,ticks) VALUES (?,?,?) ON CONFLICT (id) DO NOTHING",
            id, quote.symbol, quote.ticks
        )
        if (count == 1) return Booking.Created
        return if (find(id) == quote) Booking.Replay else Booking.Conflict
    }

    override fun find(id: UUID): Quote? = db.query(
        "SELECT symbol,ticks FROM quotes WHERE id = ?",
        { row, _ -> Quote(row.getString("symbol"), row.getLong("ticks")) }, id
    ).singleOrNull()
}
