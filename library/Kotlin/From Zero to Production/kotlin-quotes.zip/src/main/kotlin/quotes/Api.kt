package quotes

import java.util.UUID
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

data class Input(val symbol: String?, val ticks: Long?)

@RestController
@RequestMapping("/quotes")
class Api(private val store: QuoteStore) {
    @PutMapping("/{id}")
    fun put(@PathVariable("id") id: UUID, @RequestBody input: Input): ResponseEntity<Void> {
        val quote = try {
            Quote(requireNotNull(input.symbol), requireNotNull(input.ticks))
        } catch (ex: IllegalArgumentException) {
            throw ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid quote", ex)
        }
        val status = when (store.record(id, quote)) {
            Booking.Created -> HttpStatus.CREATED
            Booking.Replay -> HttpStatus.NO_CONTENT
            Booking.Conflict -> HttpStatus.CONFLICT
        }
        return ResponseEntity.status(status).build()
    }

    @GetMapping("/{id}")
    fun get(@PathVariable("id") id: UUID): Quote =
        store.find(id) ?: throw ResponseStatusException(HttpStatus.NOT_FOUND)
}
