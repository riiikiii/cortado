package quotes

fun interface Source<out T> {
    fun latest(): T
}

fun interface Sink<in T> {
    fun write(value: T)
}

fun <T, R> Source<T>.map(transform: (T) -> R): Source<R> =
    Source { transform(latest()) }

@JvmInline
value class Ticks(val value: Long) {
    init { require(value > 0) }
}

object Types {
    @JvmStatic
    fun main(args: Array<String>) {
        val source = Source { Quote("GILT", 10125) }
        val prices = source.map { Ticks(it.ticks) }
        val log: Sink<Any> = Sink { println(it) }
        val priceLog: Sink<Ticks> = log
        priceLog.write(prices.latest())
    }
}
