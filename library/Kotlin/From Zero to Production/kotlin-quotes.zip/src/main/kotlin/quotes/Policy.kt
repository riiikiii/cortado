package quotes

@DslMarker
annotation class PricingDsl

@PricingDsl
class PolicyBuilder {
    private val limits = mutableMapOf<String, LongRange>()

    fun allow(symbol: String, ticks: LongRange) {
        require(symbol.matches(Regex("[A-Z]{1,8}")))
        require(!ticks.isEmpty() && ticks.first > 0)
        require(symbol !in limits) { "Duplicate rule for $symbol" }
        limits[symbol] = ticks
    }

    fun build(): (Quote) -> Boolean {
        val snapshot = limits.toMap()
        return { quote -> snapshot[quote.symbol]?.contains(quote.ticks) == true }
    }
}

fun policy(configure: PolicyBuilder.() -> Unit): (Quote) -> Boolean =
    PolicyBuilder().apply(configure).build()

inline fun <reified T> Iterable<*>.firstInstance(): T? =
    firstOrNull { it is T } as? T

object PolicyDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val permitted = policy {
            allow("GILT", 10_000L..11_000L)
        }
        val event = listOf(null, "heartbeat", Quote("GILT", 10125)).firstInstance<Quote>()
        println(event?.let(permitted))
        println(permitted(Quote("GILT", 9999)))
    }
}
