package quotes

import kotlinx.coroutines.*

object Concurrent {
    private suspend fun readFeed(name: String, wait: Long): Quote {
        try {
            delay(wait)
            return Quote("GILT", if (name == "A") 10125 else 10130)
        } finally {
            println("closed $name")
        }
    }

    private suspend fun snapshot(budget: Long): List<Quote>? =
        withTimeoutOrNull(budget) {
            listOf(async { readFeed("A", 20) }, async { readFeed("B", 150) }).awaitAll()
        }

    @JvmStatic
    fun main(args: Array<String>) = runBlocking {
        println(snapshot(2_000)?.map { it.ticks })
        println(snapshot(60) ?: "deadline")
    }
}
