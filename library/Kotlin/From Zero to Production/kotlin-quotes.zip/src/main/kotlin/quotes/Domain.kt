package quotes

private val symbolPattern = Regex("[A-Z]{1,8}")

data class Quote(val symbol: String, val ticks: Long) {
    init {
        require(symbol.matches(symbolPattern)) { "Use 1 to 8 uppercase letters" }
        require(ticks in 1..1_000_000_000L) { "Price outside supported range" }
    }
}

fun parseLine(line: String): Quote? {
    val fields = line.split(',')
    if (fields.size != 2) return null
    val symbol = fields[0].trim()
    val ticks = fields[1].trim().toLongOrNull() ?: return null
    if (!symbol.matches(symbolPattern) || ticks !in 1..1_000_000_000L) return null
    return Quote(symbol, ticks)
}

sealed interface Booking {
    data object Created : Booking
    data object Replay : Booking
    data object Conflict : Booking
}
