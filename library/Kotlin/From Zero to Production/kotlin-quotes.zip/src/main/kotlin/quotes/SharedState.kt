package quotes

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class GateCounter {
    private val mutex = Mutex()
    private var accepted = 0

    suspend fun increment() = mutex.withLock { accepted += 1 }
    suspend fun read(): Int = mutex.withLock { accepted }
}

object SharedState {
    @JvmStatic
    fun main(args: Array<String>) = runBlocking {
        val counter = GateCounter()
        coroutineScope {
            repeat(8) {
                launch(Dispatchers.Default) {
                    repeat(1_000) { counter.increment() }
                }
            }
        }
        println(counter.read())
    }
}
