"""Run against a disposable quotes instance. Each run appends one row."""
import concurrent.futures
import json
import os
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from uuid import uuid4

root = os.getenv("BASE_URL", "http://127.0.0.1:8080")
url = f"{root}/quotes/{uuid4()}"

def put(ticks):
    body = json.dumps({"symbol": "GILT", "ticks": ticks}).encode()
    req = Request(url, data=body, method="PUT", headers={"Content-Type": "application/json"})
    try:
        with urlopen(req, timeout=8) as reply:
            return reply.status
    except HTTPError as error:
        return error.code

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as workers:
    statuses = sorted(workers.map(put, [10125] * 8))
assert statuses == [201] + [204] * 7, statuses
assert put(10130) == 409
assert put(0) == 400
assert put(1.5) == 400
with urlopen(url, timeout=8) as reply:
    quote = json.load(reply)
assert quote == {"symbol": "GILT", "ticks": 10125}, quote
print(statuses, quote)
