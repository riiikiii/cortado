use order_intake::domain::Order;
use std::{collections::HashMap, sync::Arc, thread};

trait HasQuantity {
    fn quantity(&self) -> u32;
}
impl HasQuantity for Order {
    fn quantity(&self) -> u32 {
        Order::quantity(self)
    }
}

fn total<T: HasQuantity>(items: &[T]) -> u64 {
    items.iter().map(|x| u64::from(x.quantity())).sum()
}

fn unique<'a>(orders: &'a [Order]) -> Result<Vec<&'a Order>, &'a str> {
    use std::collections::hash_map::Entry;
    let mut seen = HashMap::new();
    let mut accepted = Vec::new();
    for order in orders {
        match seen.entry(order.id()) {
            Entry::Vacant(key) => {
                key.insert(order.quantity());
                accepted.push(order);
            }
            Entry::Occupied(key) if *key.get() == order.quantity() => {}
            Entry::Occupied(_) => return Err(order.id()),
        }
    }
    Ok(accepted)
}

#[derive(Clone, Copy, Debug)]
enum Phase {
    Received,
    Validated,
    Rejected,
}
fn advance(phase: Phase, valid: bool) -> Phase {
    match (phase, valid) {
        (Phase::Received, true) => Phase::Validated,
        (Phase::Received, false) => Phase::Rejected,
        (terminal, _) => terminal,
    }
}

fn main() {
    let orders: Vec<_> = [("A-1", 30), ("A-1", 30), ("B-2", 12)]
        .into_iter()
        .map(|(id, q)| Order::new(id.into(), q).unwrap())
        .collect();
    let accepted = unique(&orders).unwrap();
    println!(
        "raw={} unique={}",
        total(&orders),
        accepted
            .iter()
            .map(|o| u64::from(o.quantity()))
            .sum::<u64>()
    );
    let shared: Arc<[Order]> = Arc::from(orders);
    let worker_view = Arc::clone(&shared);
    let raw = thread::spawn(move || total(&worker_view)).join().unwrap();
    println!("worker={} phase={:?}", raw, advance(Phase::Received, true));
    let clash = [
        Order::new("A-1".into(), 30).unwrap(),
        Order::new("A-1".into(), 31).unwrap(),
    ];
    assert_eq!(unique(&clash).unwrap_err(), "A-1");
}
