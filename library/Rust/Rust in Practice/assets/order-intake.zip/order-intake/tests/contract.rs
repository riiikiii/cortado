use axum::{
    body::Body,
    http::{Request, StatusCode},
};
use order_intake::{
    api::router,
    domain::Order,
    store::{Outcome, Store},
};
use proptest::prelude::*;
use tempfile::tempdir;
use tower::ServiceExt;

proptest! {
    #[test]
    fn positive_quantity_round_trips(n in 1..=u32::MAX) {
        prop_assert_eq!(Order::new("A-1".into(), n).unwrap().quantity(), n);
    }
}

async fn status(app: axum::Router, body: &str) -> StatusCode {
    let req = Request::post("/orders")
        .header("content-type", "application/json")
        .body(Body::from(body.to_owned()))
        .unwrap();
    app.oneshot(req).await.unwrap().status()
}

#[tokio::test]
async fn http_contract_and_restart() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("orders.sqlite");
    let app = router(Store::open(&file).unwrap(), 2);
    let order = r#"{"id":"A-1","quantity":30}"#;
    let (a, b) = tokio::join!(status(app.clone(), order), status(app.clone(), order));
    assert!(matches!((a.as_u16(), b.as_u16()), (200, 201) | (201, 200)));
    assert_eq!(
        status(app.clone(), r#"{"id":"A-1","quantity":31}"#).await,
        409
    );
    assert_eq!(
        status(app.clone(), r#"{"id":"A-2","quantity":0}"#).await,
        422
    );
    assert_eq!(
        status(app.clone(), r#"{"id":"A-2","quantity":1,"typo":1}"#).await,
        422
    );
    let reopened = Store::open(&file).unwrap();
    assert_eq!(
        reopened
            .submit(&Order::new("A-1".into(), 30).unwrap())
            .unwrap(),
        Outcome::Replay
    );
    assert_eq!(status(router(reopened, 0), order).await, 503);
}
