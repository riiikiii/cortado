use crate::domain::Order;
use rusqlite::{Connection, TransactionBehavior, params};
use std::{
    path::{Path, PathBuf},
    time::Duration,
};

#[derive(Debug, PartialEq, Eq)]
pub enum Outcome {
    Created,
    Replay,
    Conflict,
}

#[derive(Clone)]
pub struct Store(PathBuf);

impl Store {
    pub fn open(path: &Path) -> rusqlite::Result<Self> {
        let store = Self(path.to_owned());
        let db = store.connect()?;
        db.execute_batch(
            "CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY NOT NULL,
            quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 4294967295)
        )",
        )?;
        Ok(store)
    }

    fn connect(&self) -> rusqlite::Result<Connection> {
        let db = Connection::open(&self.0)?;
        db.busy_timeout(Duration::from_millis(500))?;
        Ok(db)
    }

    pub fn submit(&self, order: &Order) -> rusqlite::Result<Outcome> {
        let mut db = self.connect()?;
        let tx = db.transaction_with_behavior(TransactionBehavior::Immediate)?;
        let inserted = tx.execute(
            "INSERT INTO orders(id, quantity) VALUES (?1, ?2)
             ON CONFLICT(id) DO NOTHING",
            params![order.id(), order.quantity()],
        )?;
        let outcome = if inserted == 1 {
            Outcome::Created
        } else {
            let existing: u32 = tx.query_row(
                "SELECT quantity FROM orders WHERE id = ?1",
                [order.id()],
                |row| row.get(0),
            )?;
            if existing == order.quantity() {
                Outcome::Replay
            } else {
                Outcome::Conflict
            }
        };
        tx.commit()?;
        Ok(outcome)
    }
}
