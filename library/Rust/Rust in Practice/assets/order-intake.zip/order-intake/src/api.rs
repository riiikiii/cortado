use crate::{
    domain::Order,
    store::{Outcome, Store},
};
use axum::{
    Json, Router,
    extract::{DefaultBodyLimit, State},
    http::StatusCode,
    response::{IntoResponse, Response},
    routing::post,
};
use serde::Deserialize;
use std::sync::Arc;
use tokio::sync::Semaphore;

#[derive(Clone)]
struct App {
    store: Store,
    slots: Arc<Semaphore>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Submit {
    id: String,
    quantity: u32,
}

pub fn router(store: Store, slots: usize) -> Router {
    Router::new()
        .route("/orders", post(submit))
        .layer(DefaultBodyLimit::max(4096))
        .with_state(App {
            store,
            slots: Arc::new(Semaphore::new(slots)),
        })
}

async fn submit(State(app): State<App>, Json(input): Json<Submit>) -> Response {
    let order = match Order::new(input.id, input.quantity) {
        Ok(order) => order,
        Err(e) => return (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()).into_response(),
    };
    let Ok(slot) = app.slots.try_acquire_owned() else {
        return (StatusCode::SERVICE_UNAVAILABLE, "busy").into_response();
    };
    let task = tokio::task::spawn_blocking(move || {
        let _slot = slot;
        app.store.submit(&order)
    });
    let (status, message) = match task.await {
        Ok(Ok(Outcome::Created)) => (StatusCode::CREATED, "created"),
        Ok(Ok(Outcome::Replay)) => (StatusCode::OK, "replayed"),
        Ok(Ok(Outcome::Conflict)) => (StatusCode::CONFLICT, "id reused"),
        Ok(Err(e))
            if matches!(
                e.sqlite_error_code(),
                Some(rusqlite::ErrorCode::DatabaseBusy | rusqlite::ErrorCode::DatabaseLocked)
            ) =>
        {
            (StatusCode::SERVICE_UNAVAILABLE, "database busy")
        }
        Ok(Err(e)) => {
            tracing::error!(error = %e, "storage error");
            (StatusCode::INTERNAL_SERVER_ERROR, "storage failure")
        }
        Err(e) => {
            tracing::error!(error = %e, "worker failed");
            (StatusCode::INTERNAL_SERVER_ERROR, "worker failure")
        }
    };
    tracing::info!(
        status = status.as_u16(),
        outcome = message,
        "order submission"
    );
    (status, message).into_response()
}
