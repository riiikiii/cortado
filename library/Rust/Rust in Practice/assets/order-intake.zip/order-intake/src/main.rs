use anyhow::{Context, Result};
use clap::Parser;
use order_intake::{api::router, store::Store};
use std::{net::SocketAddr, path::PathBuf};

#[derive(Parser)]
struct Args {
    #[arg(long, default_value = "127.0.0.1:8080")]
    listen: SocketAddr,
    #[arg(long, default_value = "orders.sqlite")]
    db: PathBuf,
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();
    tracing_subscriber::fmt()
        .with_writer(std::io::stderr)
        .init();
    let store = Store::open(&args.db).context("initialise order database")?;
    let listener = tokio::net::TcpListener::bind(args.listen)
        .await
        .context("bind listener")?;
    tracing::info!(address = %listener.local_addr()?, "listening");
    axum::serve(listener, router(store, 4))
        .with_graceful_shutdown(async {
            if let Err(e) = tokio::signal::ctrl_c().await {
                tracing::error!(error = %e, "signal handler failed");
            }
        })
        .await
        .context("serve requests")
}
