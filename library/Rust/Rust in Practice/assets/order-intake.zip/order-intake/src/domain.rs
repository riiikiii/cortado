use std::num::NonZeroU32;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum Invalid {
    #[error("id must contain 1–64 ASCII letters, digits, or hyphens")]
    Id,
    #[error("quantity must be positive")]
    Quantity,
}

#[derive(Debug)]
pub struct Order {
    id: String,
    quantity: NonZeroU32,
}

impl Order {
    pub fn new(id: String, quantity: u32) -> Result<Self, Invalid> {
        if id.is_empty()
            || id.len() > 64
            || !id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
        {
            return Err(Invalid::Id);
        }
        let quantity = NonZeroU32::new(quantity).ok_or(Invalid::Quantity)?;
        Ok(Self { id, quantity })
    }
    pub fn id(&self) -> &str {
        &self.id
    }
    pub fn quantity(&self) -> u32 {
        self.quantity.get()
    }
}
